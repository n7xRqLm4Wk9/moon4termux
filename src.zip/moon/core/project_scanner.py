"""
ProjectScanner — walks workspace/ and builds a directory tree.
"""

from __future__ import annotations
import os

IGNORE_DIRS  = {".git", "__pycache__", ".mypy_cache", "node_modules", ".venv", "venv", ".env"}
IGNORE_FILES = {".DS_Store", "Thumbs.db"}
MAX_DEPTH = 6


class ProjectScanner:
    def __init__(self, workspace: str):
        self.workspace = os.path.abspath(workspace)

    def tree(self, path: str = "", depth: int = 0) -> str:
        root = os.path.join(self.workspace, path) if path else self.workspace
        if not os.path.isdir(root):
            return f"  [workspace not found: {root}]"
        lines = []
        if depth == 0:
            lines.append(f"workspace/")
        self._walk(root, lines, depth=1)
        if not lines[1:]:  # empty workspace
            lines.append("  (empty)")
        return "\n".join(lines)

    def _walk(self, directory: str, lines: list, depth: int):
        if depth > MAX_DEPTH:
            return
        try:
            entries = sorted(os.scandir(directory), key=lambda e: (not e.is_dir(), e.name))
        except PermissionError:
            return

        for i, entry in enumerate(entries):
            if entry.name in IGNORE_DIRS or entry.name in IGNORE_FILES:
                continue
            is_last = (i == len(entries) - 1)
            prefix = ("└── " if is_last else "├── ")
            indent = "│   " * (depth - 1)
            lines.append(f"{indent}{prefix}{entry.name}")
            if entry.is_dir():
                child_indent = "    " if is_last else "│   "
                self._walk(entry.path, lines, depth + 1)

    def list_files(self, extensions: list[str] | None = None) -> list[str]:
        """Return relative paths of all files in workspace (optionally filtered)."""
        result = []
        for dirpath, dirnames, filenames in os.walk(self.workspace):
            dirnames[:] = [d for d in dirnames if d not in IGNORE_DIRS]
            for fname in filenames:
                if fname in IGNORE_FILES:
                    continue
                if extensions:
                    if not any(fname.endswith(ext) for ext in extensions):
                        continue
                full = os.path.join(dirpath, fname)
                rel = os.path.relpath(full, self.workspace)
                result.append(rel)
        return sorted(result)

    def count_files(self) -> int:
        return len(self.list_files())
