"""
CostTracker — estimates token usage and cost per session.
No API calls. All local estimation.
"""
from __future__ import annotations

# Rough pricing per 1M tokens (input/output blended) USD
MODEL_COSTS: dict[str, float] = {
    "poolside/laguna-m.1:free":                   0.0,
    "poolside/laguna-xs.2:free":                  0.0,
    "moonshotai/kimi-k2.6:free":                  0.0,
    "nvidia/nemotron-3-ultra-550b-a55b:free":     0.0,
    "nvidia/nemotron-3-super-120b-a12b:free":     0.0,
    "z-ai/glm-4.5-air:free":                      0.0,
    "openai/gpt-oss-120b:free":                   0.0,
    "openai/gpt-oss-20b:free":                    0.0,
    "deepseek/deepseek-r1:free":                  0.0,
    "nvidia/nemotron-3-nano-30b-a3b:free":        0.0,
    "openrouter/owl-alpha":                       0.0,
    "google/gemma-4-31b-it:free":                 0.0,
    "google/gemma-4-26b-a4b-it:free":             0.0,
    "nvidia/nemotron-nano-9b-v2:free":            0.0,
    "openrouter/free":                            0.0,
    "anthropic/claude-3-5-haiku":                 1.0,
    "anthropic/claude-sonnet-4":                  3.0,
    "deepseek/deepseek-coder-v2":                 0.14,
    "qwen/qwen3-coder-next":                       0.5,
    "gpt-4o":                                     5.0,
    "gpt-4o-mini":                                0.15,
    "claude-3-5-haiku-20241022":                  1.0,
    "claude-sonnet-4-5":                          3.0,
    "gemini-2.0-flash":                           0.1,
    "gemini-1.5-pro":                             1.25,
}

def estimate_tokens(text: str) -> int:
    """~4 chars per token rough estimate."""
    return max(1, len(text) // 4)

class CostTracker:
    def __init__(self):
        self.total_tokens  = 0
        self.total_cost    = 0.0
        self.call_count    = 0
        self._model        = ""

    def set_model(self, model_id: str):
        self._model = model_id

    def track(self, messages: list, response: str):
        input_text  = " ".join(m.get("content","") for m in messages)
        input_tok   = estimate_tokens(input_text)
        output_tok  = estimate_tokens(response)
        total_tok   = input_tok + output_tok

        rate        = MODEL_COSTS.get(self._model, 1.0)
        cost        = (total_tok / 1_000_000) * rate

        self.total_tokens += total_tok
        self.total_cost   += cost
        self.call_count   += 1

    def summary(self) -> str:
        DIM = "\033[90m"
        WB  = "\033[97m"
        RST = "\033[0m"
        cost_str = f"${self.total_cost:.5f}" if self.total_cost > 0 else "free"
        return (f"{DIM}  calls   :{RST} {WB}{self.call_count}{RST}\n"
                f"{DIM}  tokens  :{RST} {WB}~{self.total_tokens:,}{RST}\n"
                f"{DIM}  cost    :{RST} {WB}{cost_str}{RST}")
