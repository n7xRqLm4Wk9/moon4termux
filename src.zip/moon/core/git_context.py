"""
Git context — injects git awareness into AI prompts.
Zero API tokens wasted: all local subprocess calls.
"""
from __future__ import annotations
import os, subprocess

def _run(cmd: str, cwd: str) -> str:
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True,
                           text=True, timeout=5, cwd=cwd)
        return r.stdout.strip()
    except Exception:
        return ""

def is_git_repo(workspace: str) -> bool:
    return bool(_run("git rev-parse --git-dir 2>/dev/null", workspace))

def get_git_context(workspace: str, max_chars: int = 800) -> str:
    if not is_git_repo(workspace):
        return ""

    parts = []

    # Current branch
    branch = _run("git branch --show-current", workspace)
    if branch:
        parts.append(f"branch: {branch}")

    # Staged + unstaged changes summary
    status = _run("git status --short", workspace)
    if status:
        lines = status.splitlines()
        if len(lines) > 12:
            status = "\n".join(lines[:12]) + f"\n... (+{len(lines)-12} more)"
        parts.append(f"git status:\n{status}")

    # Recent diff (unstaged) — capped tight
    diff = _run("git diff --stat HEAD 2>/dev/null", workspace)
    if diff:
        if len(diff) > 300:
            diff = diff[:300] + "..."
        parts.append(f"recent changes:\n{diff}")

    # Last 3 commits
    log = _run("git log --oneline -3 2>/dev/null", workspace)
    if log:
        parts.append(f"recent commits:\n{log}")

    result = "\n\n".join(parts)
    return result[:max_chars] if len(result) > max_chars else result

def get_git_diff_file(workspace: str, filepath: str) -> str:
    """Get diff for a specific file — used when editing."""
    if not is_git_repo(workspace):
        return ""
    diff = _run(f"git diff HEAD -- {filepath}", workspace)
    if len(diff) > 600:
        diff = diff[:600] + "..."
    return diff
