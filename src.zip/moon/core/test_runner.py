"""
TestRunner — runs tests and feeds results back to AI.
Supports: pytest, npm test, node, sh. Includes specific target testing.
"""
from __future__ import annotations
import os, subprocess, re

def detect_test_cmd(workspace: str) -> str | None:
    files = os.listdir(workspace) if os.path.isdir(workspace) else []
    if any(f.startswith("test_") or f.endswith("_test.py") for f in files): return "python -m pytest -x -q 2>&1 | head -40"
    if "pytest.ini" in files or "setup.cfg" in files or "pyproject.toml" in files: return "python -m pytest -x -q 2>&1 | head -40"
    if "package.json" in files: return "npm test 2>&1 | tail -30"
    if any(f.endswith("_test.js") or f.endswith(".test.js") or f.endswith(".spec.js") for f in files): return "node --test 2>&1 | head -30"
    if any(f.endswith("_test.ts") or f.endswith(".test.ts") for f in files): return "npx jest 2>&1 | tail -30"
    return None

def run_tests(workspace: str, cmd: str | None = None) -> dict:
    """Run tests, return {output, passed, failed, cmd}."""
    if not cmd:
        cmd = detect_test_cmd(workspace)
    if not cmd:
        return {"output": "no test runner detected", "passed": 0, "failed": 0, "cmd": None}
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True,
                           text=True, timeout=60, cwd=workspace)
        output = (r.stdout + r.stderr).strip()
        if len(output) > 2000:
            output = output[:2000] + "\n... [truncated]"
        passed = len(re.findall(r'passed|ok|PASSED', output, re.IGNORECASE))
        failed = len(re.findall(r'failed|error|FAILED|ERROR', output, re.IGNORECASE))
        return {"output": output, "passed": passed, "failed": failed, "cmd": cmd}
    except subprocess.TimeoutExpired:
        return {"output": "[test timeout after 60s]", "passed": 0, "failed": 1, "cmd": cmd}
    except Exception as e:
        return {"output": f"[error] {e}", "passed": 0, "failed": 1, "cmd": cmd}

def run_specific_test(target: str, workspace: str) -> dict:
    """Run a specific test file, function, or pattern. e.g. test_auth.py or TestUser::test_create"""
    files = os.listdir(workspace) if os.path.isdir(workspace) else []
    # Python pytest
    cmd = f"python -m pytest {target} -v 2>&1 | head -50"
    if "package.json" in files and not target.endswith(".py"):
        cmd = f"npm test -- --testNamePattern='{target}' 2>&1 | tail -30"
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True,
                           text=True, timeout=60, cwd=workspace)
        output = (r.stdout + r.stderr).strip()
        passed = len(re.findall(r'PASSED|passed', output))
        failed = len(re.findall(r'FAILED|ERROR|failed', output))
        return {"output": output, "passed": passed, "failed": failed, "cmd": cmd}
    except subprocess.TimeoutExpired:
        return {"output": "[timeout after 60s]", "passed": 0, "failed": 1, "cmd": cmd}
    except Exception as e:
        return {"output": f"[error] {e}", "passed": 0, "failed": 1, "cmd": cmd}

def format_test_result(result: dict) -> str:
    DIM = "\033[90m"
    WB  = "\033[97m"
    GRN = "\033[92m"
    RED = "\033[91m"
    RST = "\033[0m"
    if not result["cmd"]:
        return f"{DIM}  no tests found{RST}"
    icon = GRN + "✓" if result["failed"] == 0 else RED + "✗"
    out  = [f"{icon}{RST} {WB}{result['cmd']}{RST}",
            f"{DIM}{result['output']}{RST}"]
    return "\n".join(out)
