"""
Web fetch — lets Moon read raw content from URLs the user pastes,
including converting GitHub "blob" page URLs to raw.githubusercontent.com
so file contents (not HTML) get fetched.

Gated by !searchmode (default on). No API key required — plain HTTP GET.
"""
from __future__ import annotations
import re
import urllib.request
import urllib.error

MAX_FETCH_BYTES = 60_000          # cap per-URL content injected into context
TIMEOUT = 10

URL_RE = re.compile(r'https?://[^\s<>"\')\]]+')

GITHUB_BLOB_RE = re.compile(
    r'^https?://github\.com/([^/]+)/([^/]+)/blob/([^/]+)/(.+)$'
)
GITHUB_TREE_RE = re.compile(
    r'^https?://github\.com/([^/]+)/([^/]+)(?:/tree/([^/]+))?/?$'
)


def to_raw_url(url: str) -> str:
    """Convert a github.com blob URL to its raw.githubusercontent.com equivalent.
    Leaves other URLs (including ones already pointing at raw.githubusercontent.com) unchanged."""
    m = GITHUB_BLOB_RE.match(url)
    if m:
        owner, repo, ref, path = m.groups()
        return f"https://raw.githubusercontent.com/{owner}/{repo}/{ref}/{path}"
    return url


def extract_urls(text: str) -> list[str]:
    """Find http(s) URLs in free text, deduplicated, order preserved."""
    seen = set()
    out = []
    for u in URL_RE.findall(text):
        u = u.rstrip(".,);")
        if u not in seen:
            seen.add(u)
            out.append(u)
    return out


def fetch_url(url: str) -> tuple[bool, str]:
    """
    Fetch a URL's content as text.
    Returns (ok, content_or_error).
    GitHub blob URLs are transparently converted to raw URLs first.
    """
    target = to_raw_url(url)
    req = urllib.request.Request(
        target,
        headers={"User-Agent": "Moon-Terminal-IDE/1.0 (+https://github.com/) "},
    )
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            raw = resp.read(MAX_FETCH_BYTES + 1)
            ctype = resp.headers.get("Content-Type", "")
    except urllib.error.HTTPError as e:
        return False, f"HTTP {e.code} fetching {target}"
    except urllib.error.URLError as e:
        return False, f"network error fetching {target}: {e.reason}"
    except Exception as e:
        return False, f"error fetching {target}: {e}"

    if "text" not in ctype and "json" not in ctype and ctype:
        # Likely binary (image, etc.) — don't try to decode
        return False, f"unsupported content type '{ctype}' for {target}"

    try:
        text = raw.decode("utf-8", errors="replace")
    except Exception:
        return False, f"could not decode content from {target}"

    truncated = len(raw) > MAX_FETCH_BYTES
    if truncated:
        text = text[:MAX_FETCH_BYTES] + f"\n... [truncated, {len(raw)} bytes total]"

    return True, text


def build_url_context(text: str) -> tuple[str, list[str]]:
    """
    Scan `text` for URLs, fetch each (best-effort), and return a context
    block summarizing the fetched content, plus the list of URLs found.
    Returns ("", []) if no URLs are present.
    """
    urls = extract_urls(text)
    if not urls:
        return "", []

    blocks = []
    for url in urls[:3]:  # cap how many URLs get fetched per message
        ok, content = fetch_url(url)
        label = to_raw_url(url)
        if ok:
            blocks.append(f"[url: {label}]\n{content}")
        else:
            blocks.append(f"[url: {label}]\n(fetch failed: {content})")

    return "\n\n".join(blocks), urls
