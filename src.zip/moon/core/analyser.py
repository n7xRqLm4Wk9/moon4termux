"""
Analyser — proactive code analysis: run files, lint, tail logs, feed results to AI.
"""
from __future__ import annotations
import os, subprocess, re, shutil

DIM = "\033[90m"
WB  = "\033[97m"
GRN = "\033[92m"
RED = "\033[91m"
YL  = "\033[33m"
RST = "\033[0m"

# ── Run a file and capture output ─────────────────────────────────────────────
RUNNERS = {
    ".py":   "python {file}",
    ".js":   "node {file}",
    ".ts":   "npx ts-node --skipProject {file}",
    ".sh":   "bash {file}",
    ".rb":   "ruby {file}",
    ".go":   "go run {file}",
    ".php":  "php {file}",
    ".rs":   "rustc {file} -o /tmp/_moon_rs_out 2>&1 && /tmp/_moon_rs_out",
}

def run_file(path: str, workspace: str, timeout: int = 15) -> dict:
    """Run a single file, return {output, error, exit_code}."""
    ext  = os.path.splitext(path)[1].lower()
    tmpl = RUNNERS.get(ext)
    if not tmpl:
        return {"output": f"no runner for {ext}", "error": True, "exit_code": -1}
    cmd = tmpl.format(file=path)
    try:
        r = subprocess.run(
            cmd, shell=True, capture_output=True,
            text=True, timeout=timeout, cwd=workspace
        )
        combined = (r.stdout + r.stderr).strip()
        err_kws  = ("error","traceback","exception","syntaxerror",
                    "nameerror","typeerror","importerror","fatal","undefined")
        has_err  = r.returncode != 0 or any(k in combined.lower() for k in err_kws)
        return {"output": combined, "error": has_err, "exit_code": r.returncode}
    except subprocess.TimeoutExpired:
        return {"output": f"[timeout after {timeout}s]", "error": True, "exit_code": -1}
    except Exception as e:
        return {"output": f"[run error] {e}", "error": True, "exit_code": -1}


# ── Lint / static analysis ────────────────────────────────────────────────────
LINTERS = {
    ".py":  [
        ("ruff",   "ruff check {file} --output-format=concise 2>&1 | head -30"),
        ("flake8", "flake8 {file} --max-line-length=120 2>&1 | head -30"),
        ("pylint", "pylint {file} --score=no -f text 2>&1 | head -40"),
    ],
    ".js":  [
        ("eslint", "eslint {file} --no-eslintrc -c '{{\"env\":{{\"es2021\":true}}}}' 2>&1 | head -30"),
    ],
    ".ts":  [
        ("eslint", "eslint {file} 2>&1 | head -30"),
    ],
    ".go":  [
        ("go vet", "go vet {file} 2>&1"),
    ],
    ".sh":  [
        ("shellcheck", "shellcheck {file} 2>&1 | head -20"),
    ],
}

def lint_file(path: str, workspace: str) -> dict:
    """Run best available linter for file, return {tool, output, issues}."""
    ext      = os.path.splitext(path)[1].lower()
    options  = LINTERS.get(ext, [])

    for tool, tmpl in options:
        if shutil.which(tool.split()[0]):   # check tool is installed
            cmd = tmpl.format(file=path)
            try:
                r = subprocess.run(
                    cmd, shell=True, capture_output=True,
                    text=True, timeout=20, cwd=workspace
                )
                output = (r.stdout + r.stderr).strip()
                issues = len(re.findall(r'error|warning|E\d{3,}|W\d{3,}', output, re.IGNORECASE))
                return {"tool": tool, "output": output, "issues": issues}
            except Exception as e:
                return {"tool": tool, "output": f"[lint error] {e}", "issues": 0}

    return {"tool": None, "output": "no linter available (install ruff, flake8, or eslint)", "issues": 0}


# ── Log tail ──────────────────────────────────────────────────────────────────
LOG_PATTERNS = ["*.log", "logs/*.log", "log/*.log", "*.out", "nohup.out"]

def find_logs(workspace: str) -> list[str]:
    """Find log files in workspace."""
    import glob
    found = []
    for pat in LOG_PATTERNS:
        found += glob.glob(os.path.join(workspace, pat))
    return sorted(found, key=os.path.getmtime, reverse=True)[:5]

def tail_log(path: str, lines: int = 30) -> str:
    """Return last N lines of a log file."""
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            all_lines = f.readlines()
        tail = all_lines[-lines:]
        return "".join(tail).strip()
    except Exception as e:
        return f"[error reading log] {e}"

def run_with_log(cmd: str, workspace: str, timeout: int = 20) -> dict:
    """Run a command and stream/capture full output."""
    try:
        r = subprocess.run(
            cmd, shell=True, capture_output=True,
            text=True, timeout=timeout, cwd=workspace
        )
        output = (r.stdout + r.stderr).strip()
        return {"output": output, "exit_code": r.returncode,
                "error": r.returncode != 0}
    except subprocess.TimeoutExpired:
        return {"output": f"[timeout after {timeout}s]", "exit_code": -1, "error": True}
    except Exception as e:
        return {"output": f"[error] {e}", "exit_code": -1, "error": True}


# ── Specific test targeting ───────────────────────────────────────────────────
def run_specific_test(target: str, workspace: str) -> dict:
    """
    Run a specific test file, function, or pattern.
    target can be: 'test_auth.py', 'test_login', 'TestUser::test_create'
    """
    files = os.listdir(workspace) if os.path.isdir(workspace) else []

    # Python
    if target.endswith(".py") or "test_" in target or "::" in target:
        # pytest supports file::class::method syntax natively
        cmd = f"python -m pytest {target} -v 2>&1 | head -50"
        r   = subprocess.run(cmd, shell=True, capture_output=True,
                             text=True, timeout=60, cwd=workspace)
        output = (r.stdout + r.stderr).strip()
        passed = len(re.findall(r'PASSED', output))
        failed = len(re.findall(r'FAILED|ERROR', output))
        return {"output": output, "passed": passed, "failed": failed, "cmd": cmd}

    # JS
    if "package.json" in files:
        cmd = f"npm test -- --testNamePattern='{target}' 2>&1 | tail -30"
        r   = subprocess.run(cmd, shell=True, capture_output=True,
                             text=True, timeout=60, cwd=workspace)
        output = (r.stdout + r.stderr).strip()
        return {"output": output, "passed": 0, "failed": int("fail" in output.lower()), "cmd": cmd}

    return {"output": f"couldn't determine test runner for: {target}",
            "passed": 0, "failed": 0, "cmd": None}


# ── Format helpers ────────────────────────────────────────────────────────────
def fmt_run(path: str, result: dict) -> str:
    icon = f"{GRN}✓{RST}" if not result["error"] else f"{RED}✗{RST}"
    out  = [f"  {icon} ran {WB}{path}{RST}  {DIM}(exit {result['exit_code']}){RST}"]
    if result["output"]:
        for line in result["output"].splitlines()[:25]:
            out.append(f"  {DIM}{line}{RST}")
    return "\n".join(out)

def fmt_lint(path: str, result: dict) -> str:
    if not result["tool"]:
        return f"  {DIM}{result['output']}{RST}"
    icon = f"{GRN}✓{RST}" if result["issues"] == 0 else f"{YL}!{RST}"
    out  = [f"  {icon} {DIM}{result['tool']}{RST}  {WB}{path}{RST}  "
            f"{DIM}({result['issues']} issue{'s' if result['issues']!=1 else ''}){RST}"]
    if result["output"] and result["issues"] > 0:
        for line in result["output"].splitlines()[:20]:
            out.append(f"    {DIM}{line}{RST}")
    return "\n".join(out)
