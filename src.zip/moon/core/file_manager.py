from __future__ import annotations
import os, shutil

class FileManager:
    def __init__(self, workspace: str):
        self.workspace = os.path.abspath(workspace)
        os.makedirs(self.workspace, exist_ok=True)

    def _resolve(self, path: str) -> str:
        full = os.path.normpath(path if os.path.isabs(path) else os.path.join(self.workspace, path))
        if full != self.workspace and not full.startswith(self.workspace + os.sep):
            raise ValueError(f"Path outside workspace: {path}")
        return full

    def read(self, path: str) -> str:
        full = self._resolve(path)
        if not os.path.exists(full): return f"  [error] not found: {path}"
        if os.path.isdir(full): return f"  [error] is a directory: {path}"
        try:
            with open(full, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
            return f"── {path} ({len(content.splitlines())} lines) ──\n{content}"
        except Exception as e:
            return f"  [error] {e}"

    def write(self, path: str, content: str, silent: bool = False) -> str:
        full = self._resolve(path)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        existed = os.path.exists(full)
        try:
            with open(full, "w", encoding="utf-8") as f:
                f.write(content)
            return "" if silent else f"  ✓ {'updated' if existed else 'created'}: {path}"
        except Exception as e:
            return f"  [error] {e}"

    def delete(self, path: str) -> str:
        full = self._resolve(path)
        if not os.path.exists(full): return f"  [error] not found: {path}"
        try:
            shutil.rmtree(full) if os.path.isdir(full) else os.remove(full)
            return f"  ✓ deleted: {path}"
        except Exception as e:
            return f"  [error] {e}"

    def mkdir(self, path: str) -> str:
        try:
            os.makedirs(self._resolve(path), exist_ok=True)
            return f"  ✓ folder: {path}"
        except Exception as e:
            return f"  [error] {e}"

    def ls(self, path: str = ".") -> list[str]:
        full = self._resolve(path)
        return sorted(os.listdir(full)) if os.path.isdir(full) else []

    def exists(self, path: str) -> bool:
        try: return os.path.exists(self._resolve(path))
        except: return False

    def read_capped(self, path: str, max_chars: int = 4000) -> str:
        full = self._resolve(path)
        if not os.path.isfile(full): return ""
        try:
            with open(full, "r", encoding="utf-8", errors="replace") as f:
                content = f.read(max_chars + 1)
            return (content[:max_chars] + "\n... [truncated]") if len(content) > max_chars else content
        except: return ""

    def apply_diff(self, path: str, diff_text: str) -> str:
        full = self._resolve(path)
        if not os.path.exists(full): return f"[error] not found: {path}"
        try:
            with open(full, "r", encoding="utf-8") as f:
                lines = f.readlines()

            removed, added = [], []
            for line in diff_text.splitlines():
                if line.startswith(("--- ","--- ","@@ ")): continue
                if line.startswith("-") and not line.startswith("---"):
                    removed.append(line[1:].rstrip("\n"))
                elif line.startswith("+") and not line.startswith("+++"):
                    added.append(line[1:].rstrip("\n"))

            result, add_idx = [], 0
            for line in lines:
                stripped = line.rstrip("\n")
                if removed and stripped == removed[0]:
                    if add_idx < len(added):
                        result.append(added[add_idx] + "\n")
                        add_idx += 1
                    removed.pop(0)
                else:
                    result.append(line)
            result.extend(a + "\n" for a in added[add_idx:])

            with open(full, "w", encoding="utf-8") as f:
                f.writelines(result)
            return f"patch applied: {path}"
        except Exception as e:
            return f"[error] diff failed: {e}"
