from __future__ import annotations
import os, re
from core.file_manager import FileManager
from core.project_scanner import ProjectScanner

TOKEN_BUDGET  = 2500
SNIPPET_RADIUS = 25
CODE_EXTENSIONS = {".py",".js",".ts",".jsx",".tsx",".java",".go",".rs",".c",".cpp",".h",".cs",".html",".css",".json",".yaml",".yml",".sh",".sql"}
SKIP_CONTEXT = {"hi","hello","hey","thanks","ok","okay","yes","no","sure","cool","nice","great","good"}

class ContextEngine:
    def __init__(self, workspace: str):
        self.workspace = os.path.abspath(workspace)
        self.fm = FileManager(workspace)
        self.scanner = ProjectScanner(workspace)

    def build_context(self, query: str) -> str:
        q = query.lower().strip()
        if any(q.startswith(s) for s in SKIP_CONTEXT): return ""
        if len(query.split()) < 4 and not re.search(r'\w+\.\w{1,6}', query): return ""

        parts = []
        budget = TOKEN_BUDGET
        mentioned = self._extract_file_mentions(query)

        for fname in mentioned:
            content = self._slice_relevant(fname, query)
            if content:
                block = f"[{fname}]\n{content}"
                parts.append(block)
                budget -= len(block)
                if budget < 300: break

        if not mentioned and self._needs_project_context(query):
            tree = self.scanner.tree()
            block = f"[tree]\n{tree}"
            if len(block) < budget:
                parts.append(block)

        return "\n\n".join(parts).strip()

    def _slice_relevant(self, path: str, query: str) -> str:
        content = self.fm.read_capped(path, 8000)
        if not content: return ""
        lines = content.splitlines()
        if len(lines) <= 60: return content

        keywords = self._extract_keywords(query)
        scores = [(sum(1 for kw in keywords if kw in line.lower()), i) for i, line in enumerate(lines)]
        best = max(scores, key=lambda x: x[0])

        if best[0] == 0:
            return "\n".join(lines[:50]) + f"\n... [{len(lines)-50} more lines]"

        center = best[1]
        start  = max(0, center - SNIPPET_RADIUS)
        end    = min(len(lines), center + SNIPPET_RADIUS)
        return f"... [lines {start+1}-{end} of {len(lines)}]\n" + "\n".join(lines[start:end])

    def summarize_project(self) -> str:
        lines = []
        for fpath in self.scanner.list_files(list(CODE_EXTENSIONS)):
            content = self.fm.read_capped(fpath, 100)
            if content:
                lines.append(f"  {fpath}: {content.splitlines()[0][:80]}")
            if len("\n".join(lines)) > 2000: break
        return "\n".join(lines) or "  (empty)"

    def _extract_file_mentions(self, query: str) -> list[str]:
        found = []
        for c in re.findall(r'[\w./\\-]+\.\w{1,10}', query):
            c = c.replace("\\", "/")
            if self.fm.exists(c): found.append(c)
        return found

    def _extract_keywords(self, query: str) -> list[str]:
        stop = {"create","edit","delete","read","file","the","a","an","in","for","to","of","and","or","my","this","that","code","function","class","add","with","use","make","fix","bug","error","update","change","modify"}
        return [w for w in re.findall(r'\b[a-zA-Z_]\w*\b', query.lower()) if w not in stop and len(w) > 2]

    def _needs_project_context(self, query: str) -> bool:
        return any(t in query.lower() for t in {"project","analyze","refactor","structure","folder","all files","codebase","overview","workspace","tree"})
