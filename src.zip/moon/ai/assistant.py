from __future__ import annotations
import re, os, subprocess, threading, sys, time, shutil, json
from ai.openrouter_client import call_openrouter
from ai.router import get_active_model, get_active_label, set_model, set_default_model, show_model_menu
from core.file_manager import FileManager
from core.project_scanner import ProjectScanner
from core.context_engine import ContextEngine
from core.git_context import get_git_context, is_git_repo
from core.test_runner import run_tests, format_test_result, run_specific_test
from core.cost_tracker import CostTracker
from core.analyser import lint_file, find_logs, tail_log, fmt_lint, RUNNERS
from core.web_fetch import build_url_context, extract_urls
from config.settings import (
    SECURITY_MODES, DEFAULT_SECURITY_MODE, SANDBOX_DIR_NAME,
    load_security_mode, save_security_mode, _find_or_create_sandbox,
)

DIM  = "\033[90m"
WB   = "\033[97m"
W    = "\033[37m"
GRN  = "\033[92m"
RED  = "\033[91m"
YL   = "\033[33m"
RST  = "\033[0m"

MAX_HISTORY   = 16
MAX_FIX_LOOPS = 3
CHUNK_TOKENS  = 6000

# ── Safety config ─────────────────────────────────────────────────────────────
_cfg = {"autorun": False, "security_mode": DEFAULT_SECURITY_MODE, "searchmode": True}  # mutable — avoids global keyword issues

# Legacy default workspace (used only as an extra allowed prefix for backward compat)
LEGACY_WORKSPACE_DIR = os.path.abspath(os.path.expanduser("~/moon_workspace"))
os.makedirs(LEGACY_WORKSPACE_DIR, exist_ok=True)

# Patterns to neutralise in file content before sending to AI (prompt injection)
INJECTION_PATTERNS = [
    re.compile(r'<run_cmd>.*?</run_cmd>',         re.DOTALL | re.IGNORECASE),
    re.compile(r'<write_file[^>]*>.*?</write_file>', re.DOTALL | re.IGNORECASE),
    re.compile(r'<delete_file[^>]*/?>',              re.IGNORECASE),
    re.compile(r'(?i)(ignore previous|disregard|new instruction|system prompt|you are now|act as)',),
]

def sanitize_file_content(content: str) -> str:
    """Strip prompt injection attempts from file content before sending to AI."""
    for pat in INJECTION_PATTERNS:
        content = pat.sub('[REDACTED]', content)
    return content

def _within(p: str, base: str) -> bool:
    base = base.rstrip(os.sep)
    return p == base or p.startswith(base + os.sep)

def validate_path(path: str, workspace: str | None = None) -> tuple[bool, str]:
    """
    Validate a path is allowed under the current security mode.
    Returns (is_safe, resolved_path).

    - low    : workspace, ~, /sdcard, /storage allowed (system dirs blocked)
    - medium/high : only the sandbox workspace (moon-prj on /sdcard) allowed
    """
    resolved = os.path.realpath(os.path.abspath(os.path.expanduser(path)))
    mode = _cfg.get("security_mode", DEFAULT_SECURITY_MODE)

    blocked_prefixes = (
        '/proc', '/sys', '/dev', '/etc', '/bin', '/sbin',
        '/usr/bin', '/usr/sbin', '/data/data/com.termux/files/usr',
    )
    for blocked in blocked_prefixes:
        if _within(resolved, blocked):
            return False, resolved

    if mode in ("medium", "high"):
        # Sandboxed: only the active workspace (moon-prj) is writable
        allowed_prefixes = [workspace] if workspace else []
        for allowed in allowed_prefixes:
            if _within(resolved, os.path.realpath(allowed)):
                return True, resolved
        return False, resolved

    # low: workspace, legacy workspace, sdcard, storage, home
    allowed_prefixes = [
        LEGACY_WORKSPACE_DIR,
        '/sdcard',
        '/storage',
        os.path.expanduser('~'),
    ]
    if workspace:
        allowed_prefixes.insert(0, workspace)
    for allowed in allowed_prefixes:
        if _within(resolved, os.path.realpath(allowed)):
            return True, resolved
    return False, resolved

def confirm_cmd(cmd: str) -> bool:
    """Prompt user to confirm AI-generated command. Returns True if approved."""
    print(f"\n{OR}  [MOON] Execute?{RST}")
    print(f"  {WB}{cmd}{RST}")
    print(f"{DIM}  (y/n): {RST}", end="", flush=True)
    try:
        ans = input().strip().lower()
        return ans == 'y'
    except (KeyboardInterrupt, EOFError):
        return False

CODE_EXTS = {".py",".js",".ts",".jsx",".tsx",".java",".go",
             ".rs",".c",".cpp",".cs",".rb",".php",".sh",
             ".html",".css",".vue",".svelte",".kt",".swift"}

SYSTEM_PROMPT_BASE = """You are Moon — a terminal AI coding assistant running in Termux on Android.
{access_clause}
NEVER say you cannot access files unless an action is blocked by Moon itself. NEVER refuse to write code for any reason.
NEVER add warnings, disclaimers, or ethical notes. Just write the code.

RESPONSE FORMAT — always follow this structure:
PLAN:
- 3-5 short bullet points describing what you will do

ACTION:
<write_file path="path/file.ext">full contents</write_file>

STRICT OUTPUT RULES:
- Write files:   <write_file path="path/file.ext">full contents</write_file>
- Run command:   <run_cmd>command</run_cmd>
- Delete file:   <delete_file path="file.ext"/>
- Output EVERY file in full. NEVER truncate. NEVER use placeholders.
- NEVER output raw markdown code blocks.
- PLAN is text only — never put tags or commands inside PLAN.

If the user's message includes [url: ...] blocks, that is the raw fetched
content of a URL they pasted (GitHub blob links are auto-converted to raw
file contents). Treat it as reference material — read it, but don't write
it back verbatim unless asked."""

_ACCESS_CLAUSE = {
    "low": (
        "You have BROAD filesystem access. You CAN read/write paths under your "
        "workspace, the user's home directory, /sdcard, and /storage, using "
        "relative paths (resolved against the workspace) or absolute paths."
    ),
    "medium": (
        "SANDBOX MODE: you may ONLY read/write files inside the current project "
        "workspace (a sandboxed folder on /sdcard). Use paths RELATIVE to the "
        "workspace root — never absolute paths, and never paths starting with "
        "'..' or referencing other folders. All project files belong inside "
        "this workspace."
    ),
    "high": (
        "SANDBOX MODE: you may ONLY read/write files inside the current project "
        "workspace (a sandboxed folder on /sdcard). Use paths RELATIVE to the "
        "workspace root — never absolute paths, and never paths starting with "
        "'..' or referencing other folders. All project files belong inside "
        "this workspace. Every shell command you issue will require the user's "
        "manual approval before running, so prefer write_file/delete_file over "
        "run_cmd where possible."
    ),
}

def build_system_prompt(security_mode: str) -> str:
    clause = _ACCESS_CLAUSE.get(security_mode, _ACCESS_CLAUSE["medium"])
    return SYSTEM_PROMPT_BASE.format(access_clause=clause)

# Backward-compatible default (low-equivalent access clause)
SYSTEM_PROMPT = build_system_prompt("low")

ANALYSE_SYSTEM = """You are a precise code debugger. You will be given ONE file at a time with line numbers.

Your job:
1. Read every line carefully
2. Find ALL bugs: syntax errors, logic bugs, undefined variables, missing returns, race conditions, wrong API calls, typos in strings
3. Report each bug EXACTLY as:
   Bug [filename:line]: description
4. Then output the COMPLETE fixed file:
   <write_file path="ORIGINAL_FULL_PATH">complete fixed file contents</write_file>
5. If the file is clean:
   Clean: filename

RULES:
- Use the EXACT original file path in write_file
- Write the COMPLETE file — never truncate, never use "... rest of file ..."
- Be precise about line numbers
- Do not add markdown formatting like ** or __
- Do not write explanations outside the Bug/Clean/write_file format"""

INTENT_PROMPTS = {
    "generate": "Output complete files using write_file tags. No explanation.",
    "patch":    "Return ONLY a unified diff:\n--- a/file\n+++ b/file\n@@ ... @@\n- old\n+ new\nDo not rewrite full files.",
    "explain":  "Reply in 2-3 lines max. No code unless asked.",
    "test":     "Run tests, analyze failures, output ONLY the fix using write_file or diff tags.",
}

GREETINGS = {"hi","hello","hey","yo","sup","hiya","howdy","greetings","what's up","whats up"}

SLASH_ALIASES = {
    "/help":    "!help",    "/model":   "!model",
    "/tree":    "!tree",    "/clear":   "!clear",
    "/status":  "!status",  "/cost":    "!cost",
    "/test":    "!test",    "/git":     "!git",
    "/analyse": "!analyse", "/lint":    "!lint",
    "/log":     "!log",     "/undo":    "!undo",
    "/security": "!security",
}

OR = "\033[38;2;157;92;255m"   # purple #9d5cff

_THINK_LABELS = [
    "Thinking","Pondering","Reasoning","Reflecting","Considering",
    "Analyzing","Processing","Computing","Evaluating","Discombobulating",
]

def tool_line(icon: str, name: str, arg: str = "", running: bool = False):
    """Print a Claude Code style tool call line:  └ Name(arg)\n    Running..."""
    arg_short = (arg[:60] + "...") if len(arg) > 63 else arg
    arg_str   = f'({arg_short})' if arg_short else ""
    sys.stdout.write(f"\r\033[K{OR}  \u2514 {RST}{WB}{name}{RST}{DIM}{arg_str}{RST}\n")
    if running:
        sys.stdout.write(f"{DIM}    Running...{RST}\n")
    sys.stdout.flush()

def agent_header(task: str = ""):
    """Print Agent(...) header like Claude Code."""
    label = (task[:58] + "...") if len(task) > 61 else task
    sys.stdout.write(f"\n{OR}  Agent{RST}{DIM}({label}){RST}\n")
    sys.stdout.flush()

def status(msg: str):
    """Print a status line that stays visible."""
    sys.stdout.write(f"\r\033[K{DIM}  · {msg}{RST}\n")
    sys.stdout.flush()

def clean_markdown(text: str) -> str:
    """Strip markdown formatting from AI plain-text output."""
    text = re.sub(r'\*\*([^*]+)\*\*', r'\1', text)   # **bold**
    text = re.sub(r'\*([^*]+)\*',     r'\1', text)   # *italic*
    text = re.sub(r'__([^_]+)__',     r'\1', text)   # __bold__
    text = re.sub(r'`([^`]+)`',       r'\1', text)   # `code`
    text = re.sub(r'^#{1,6}\s+',      '',    text, flags=re.MULTILINE)  # headers
    text = re.sub(r'^\s*[-*]\s+',     '  · ', text, flags=re.MULTILINE) # bullets
    return text.strip()

def detect_intent(text: str) -> str:
    t = text.lower()
    if any(w in t for w in ("test","pytest","failing","assertion","unittest","spec")): return "test"
    if any(w in t for w in ("analyse","analyze","review","audit","inspect","look at",
                             "what's wrong","whats wrong","find bugs","find issues",
                             "any issues","any bugs","any errors","check for bugs",
                             "check the","search for bugs","scan for")): return "analyse"
    if any(w in t for w in ("fix","bug","error","edit","update","modify","refactor","patch","change")): return "patch"
    if any(w in t for w in ("explain","what is","how does","why","describe","tell me","what does")): return "explain"
    return "generate"

def extract_path(text: str) -> str | None:
    # 1. Explicit absolute path
    m = re.search(r'(/(?:sdcard|storage|data|home|mnt)[^\s,\'"]*)', text)
    if m: return m.group(1).rstrip(".,")
    # 2. ~ path
    m = re.search(r'(~/[^\s,\'"]+)', text)
    if m: return os.path.expanduser(m.group(1).rstrip(".,"))
    # 3. "folder X in/inside sdcard"
    m = re.search(r'(?:folder|dir|directory|project)\s+["\']?(\w[\w.-]*)["\']?\s+(?:in|on|inside|at|from)\s+sdcard', text, re.IGNORECASE)
    if m: return f"/sdcard/{m.group(1)}"
    # 4. "X folder in sdcard"
    m = re.search(r'["\']?(\w[\w.-]*)["\']?\s+(?:folder|dir|directory|project)\s+(?:in|on|inside|at|from)\s+sdcard', text, re.IGNORECASE)
    if m: return f"/sdcard/{m.group(1)}"
    # 5. "in sdcard/X"
    m = re.search(r'(?:in|inside|on|at|from)\s+sdcard/(\w[\w.-/]*)', text, re.IGNORECASE)
    if m: return f"/sdcard/{m.group(1).rstrip('/')}"
    # 6. "the X folder" — check sdcard
    m = re.search(r'(?:the\s+)?["\']?(\w[\w.-]*)["\']?\s+(?:folder|dir|project|directory|repo)', text, re.IGNORECASE)
    if m:
        candidate = f"/sdcard/{m.group(1)}"
        if os.path.exists(candidate): return candidate
    # 7. Bare word that exists on sdcard/home
    words = re.findall(r'\b([a-zA-Z][\w.-]{2,})\b', text)
    skip  = {"analyse","analyze","folder","sdcard","inside","check","bugs","files",
              "code","review","find","search","look","the","and","for","bug","patch",
              "fix","each","file","fule","moon","termux","project","please","just"}
    for w in words:
        if w.lower() in skip: continue
        for base in ("/sdcard", os.path.expanduser("~"), "/storage/emulated/0"):
            p = os.path.join(base, w)
            if os.path.isdir(p): return p
    return None


class Thinking:
    """Claude Code style spinner: rotating labels, live timer, token count."""
    FRAMES = ["⠋","⠙","⠹","⠸","⠼","⠴","⠦","⠧","⠇","⠏"]

    def __init__(self):
        self._stop    = False
        self._thread  = None
        self._force   = None
        self._start_t = 0.0
        self._tokens  = 0

    def start(self, label: str = None):
        self._stop    = False
        self._force   = label
        self._start_t = time.time()
        self._tokens  = 0
        self._thread  = threading.Thread(target=self._animate, daemon=True)
        self._thread.start()

    def set(self, label: str):
        self._force = label

    def set_tokens(self, n: int):
        self._tokens = n

    def stop(self):
        self._stop = True
        if self._thread: self._thread.join()
        sys.stdout.write(f"\r\033[K")
        sys.stdout.flush()

    def _animate(self):
        i = 0
        while not self._stop:
            elapsed   = time.time() - self._start_t
            label_idx = int(elapsed / 4) % len(_THINK_LABELS)
            label     = self._force if self._force else _THINK_LABELS[label_idx]
            tok_str   = f" \u00b7 \u2193 {self._tokens} tokens" if self._tokens > 0 else ""
            sys.stdout.write(
                f"\r\033[K{OR}{self.FRAMES[i%len(self.FRAMES)]} "
                f"{label}...{RST} {DIM}({elapsed:.0f}s{tok_str}){RST}"
            )
            sys.stdout.flush()
            time.sleep(0.08)
            i += 1


class UndoManager:
    """Backs up files before writing, supports single-level undo."""

    UNDO_DIR = os.path.join(os.path.expanduser("~"), ".moon_undo")

    def __init__(self):
        os.makedirs(self.UNDO_DIR, exist_ok=True)
        self._manifest: list[dict] = []   # [{original, backup}, ...]

    def backup(self, path: str):
        """Back up a file before overwriting. Creates backup in ~/.moon_undo/"""
        if not os.path.exists(path):
            return  # new file, nothing to back up
        rel      = path.replace("/", "_").replace("\\", "_").lstrip("_")
        ts       = str(int(time.time() * 1000))
        backup   = os.path.join(self.UNDO_DIR, f"{ts}_{rel}")
        shutil.copy2(path, backup)
        self._manifest.append({"original": path, "backup": backup})

    def save_manifest(self):
        """Persist current session's manifest so !undo works after restart."""
        mpath = os.path.join(self.UNDO_DIR, "manifest.json")
        try:
            with open(mpath, "w") as f:
                json.dump(self._manifest, f)
        except Exception:
            pass

    def undo(self) -> str:
        """Restore all files backed up in this session."""
        # Try in-memory first, then disk manifest
        manifest = self._manifest
        if not manifest:
            mpath = os.path.join(self.UNDO_DIR, "manifest.json")
            if os.path.exists(mpath):
                try:
                    with open(mpath) as f:
                        manifest = json.load(f)
                except Exception:
                    pass

        if not manifest:
            return f"{DIM}  nothing to undo{RST}"

        restored = []
        for entry in reversed(manifest):
            orig, bak = entry["original"], entry["backup"]
            if os.path.exists(bak):
                os.makedirs(os.path.dirname(os.path.abspath(orig)), exist_ok=True)
                shutil.copy2(bak, orig)
                restored.append(orig)

        self._manifest.clear()
        # Clear disk manifest
        mpath = os.path.join(self.UNDO_DIR, "manifest.json")
        try:
            os.remove(mpath)
        except Exception:
            pass

        if restored:
            lines = [f"{GRN}  ✓ undone — {len(restored)} file{'s' if len(restored)>1 else ''} restored{RST}"]
            for r in restored:
                lines.append(f"  {DIM}↩ {r}{RST}")
            return "\n".join(lines)
        return f"{DIM}  nothing to restore{RST}"


class Assistant:
    def __init__(self, workspace: str, security_mode: str | None = None):
        self.workspace = os.path.abspath(workspace)
        self.fm        = FileManager(workspace)
        self.scanner   = ProjectScanner(workspace)
        self.ctx       = ContextEngine(workspace)
        self.tracker   = CostTracker()
        self.undo      = UndoManager()
        self.history:  list[dict] = []
        self.thinking  = Thinking()
        self._indexed  = False
        self.tracker.set_model(get_active_model())

        mode = (security_mode or load_security_mode()).lower()
        if mode not in SECURITY_MODES:
            mode = DEFAULT_SECURITY_MODE
        self.security_mode = mode
        _cfg["security_mode"] = mode
        # High security: every AI-issued shell command needs manual approval,
        # regardless of the !autorun setting.
        if mode == "high":
            _cfg["autorun"] = False

    def _lazy_index(self):
        if self._indexed: return
        self._indexed = True
        n = self.scanner.count_files()
        if n > 0: status(f"indexed {n} files")

    # ── Main entry ────────────────────────────────────────────────────────────
    def chat(self, user_input: str) -> str:
        user_input = user_input.strip()
        if not user_input: return ""

        low = user_input.lower().strip()

        for slash, bang in SLASH_ALIASES.items():
            if low == slash or low.startswith(slash + " "):
                user_input = bang + user_input[len(slash):]
                low = user_input.lower().strip()
                break

        # ── Built-in commands ─────────────────────────────────────────────────
        if low in ("!model","!models"):       return self._switch_model()
        if low in ("!help","help","?"):       return self._help()
        if low in ("!tree","tree"):           return f"{DIM}{self.scanner.tree()}{RST}"
        if low in ("!clear","clear"):
            self.history.clear()
            return f"{DIM}  [history cleared]{RST}"
        if low in ("!undo","undo"):           return self.undo.undo()
        if low.startswith("!autorun"):
            if self.security_mode == "high":
                return (f"{OR}  autorun is disabled in HIGH security mode{RST}\n"
                        f"{DIM}  every command requires manual approval · switch with !security{RST}")
            parts = user_input.strip().split()
            val   = parts[1].lower() if len(parts) > 1 else ""
            if val in ("true","on","1","yes"):
                _cfg["autorun"] = True
                return f"{OR}  ⚠ autorun ON — AI commands execute immediately{RST}"
            elif val in ("false","off","0","no"):
                _cfg["autorun"] = False
                return f"{GRN}  ✓ autorun OFF — AI commands require confirmation{RST}"
            else:
                state = f"{OR}ON{RST}" if _cfg["autorun"] else f"{GRN}OFF{RST}"
                return f"  autorun: {state}  {DIM}(use !autorun true/false){RST}"
        if low.startswith("!security"):
            return self._security_cmd(user_input)
        if low.startswith("!searchmode"):
            parts = user_input.strip().split()
            val   = parts[1].lower() if len(parts) > 1 else ""
            if val in ("true","on","1","yes"):
                _cfg["searchmode"] = True
                return f"{GRN}  ✓ searchmode ON{RST} {DIM}— URLs in your messages will be fetched for context{RST}"
            elif val in ("false","off","0","no"):
                _cfg["searchmode"] = False
                return f"{DIM}  · searchmode OFF — URLs will be ignored{RST}"
            else:
                state = f"{GRN}ON{RST}" if _cfg["searchmode"] else f"{DIM}OFF{RST}"
                return f"  searchmode: {state}  {DIM}(use !searchmode true/false){RST}"
        if low == "!cost":                    return self.tracker.summary()
        if low == "!git":
            gc = get_git_context(self.workspace)
            return f"{DIM}{gc}{RST}" if gc else f"{DIM}  not a git repo{RST}"
        if low == "!status":                  return self._status_cmd()
        if low.startswith("!read "):
            target = user_input.split(" ",1)[1].strip()
            tool_line("", "Reading file", target, running=True)
            return self.fm.read(target)
        if low.startswith("!run "):           return self._shell(user_input.split(" ",1)[1].strip())
        if low.startswith("!delete "):        return self._confirm_delete(user_input.split(" ",1)[1].strip())
        if low.startswith("!mkdir "):
            d = user_input.split(" ",1)[1].strip()
            os.makedirs(os.path.join(self.workspace, d), exist_ok=True)
            return f"{GRN}  ✓{RST} {WB}{d}{RST}"
        if low.startswith("!default"):
            parts = user_input.strip().split()
            if len(parts) < 2: return f"{DIM}  usage: !default <number>{RST}"
            label = set_default_model(parts[1])
            if label:
                self.tracker.set_model(get_active_model())
                return f"{GRN}  ✓{RST} {WB}Default → {label}{RST} {DIM}(saved){RST}"
            return f"{RED}  [invalid]{RST} {DIM}use !model to see numbers{RST}"
        if low.startswith("!test"):
            parts = user_input.strip().split(None, 1)
            return self._run_specific_test(parts[1]) if len(parts) > 1 else self._run_tests_cmd()
        if low.startswith("!analyse") or low.startswith("!analyze"):
            parts = user_input.strip().split(None, 1)
            return self._analyse_cmd(parts[1].strip() if len(parts) > 1 else None)
        if low.startswith("!lint"):
            parts = user_input.strip().split(None, 1)
            return self._lint_cmd(parts[1].strip() if len(parts) > 1 else None)
        if low.startswith("!log"):
            parts = user_input.strip().split(None, 1)
            return self._log_cmd(parts[1].strip() if len(parts) > 1 else None)
        if low.startswith("!search "):
            return self._grep(user_input.split(" ",1)[1].strip())
        if low.startswith("!sync"):
            parts = user_input.strip().split(None, 1)
            return self._sync(parts[1].strip() if len(parts) > 1 else "/sdcard/moon")

        if low in GREETINGS:
            return f"{WB}  Hey. What are we building?{RST}"

        self._lazy_index()
        intent = detect_intent(user_input)

        # Analyse → always goes direct, reads files itself
        if intent == "analyse":
            path = extract_path(user_input)
            return self._analyse_cmd(path)

        # ── Regular AI call ───────────────────────────────────────────────────
        mentioned = [f for f in re.findall(r'[\w./\\-]+\.\w{1,10}', user_input)
                     if os.path.exists(os.path.join(self.workspace, f))]
        status("Thinking")
        agent_header(user_input[:60])
        context = self.ctx.build_context(user_input)
        git_ctx = get_git_context(self.workspace, max_chars=400)
        if git_ctx:
            context = git_ctx + ("\n\n" + context if context else "")

        # searchmode: fetch any URLs (incl. GitHub blob -> raw) mentioned in the message
        if _cfg["searchmode"]:
            urls = extract_urls(user_input)
            for u in urls:
                tool_line("", "Reading file" if "github.com" in u or "raw.githubusercontent.com" in u else "Fetching URL", u, running=True)
            url_ctx, _ = build_url_context(user_input)
            if url_ctx:
                context = url_ctx + ("\n\n" + context if context else "")

        extra = ""
        if intent == "test":
            tool_line("", "Running tests", "", running=True)
            result = run_tests(self.workspace)
            extra  = f"TEST OUTPUT:\n{result['output']}"
            if result["failed"] == 0:
                return f"{GRN}  ✓ all tests passed{RST}"

        msgs = self._build_messages(user_input, context, intent, extra)

        self.thinking.start()
        try:
            raw = call_openrouter(msgs, get_active_model(), max_tokens=16000)
        finally:
            self.thinking.stop()

        self.tracker.track(msgs, raw)
        self.history.append({"role": "user",     "content": user_input})
        self.history.append({"role": "assistant", "content": raw})
        if len(self.history) > MAX_HISTORY * 2:
            self.history = self.history[-(MAX_HISTORY * 2):]

        result, _ = self._process(raw)

        if intent in ("generate","patch","test"):
            result = self._tool_loop(result)

        if result: status("Done")
        return result

    def _build_messages(self, user_input, context, intent="generate", extra=""):
        system = build_system_prompt(self.security_mode) + "\n\n" + INTENT_PROMPTS.get(intent, "")
        if context: system += f"\n\nPROJECT CONTEXT:\n{context}"
        if extra:   system += f"\n\n{extra}"
        msgs = [{"role": "system", "content": system}]
        msgs += self.history[-(MAX_HISTORY * 2):]
        msgs.append({"role": "user", "content": user_input})
        return msgs

    # ── Response processor ────────────────────────────────────────────────────
    def _process(self, response: str) -> tuple[str, list]:
        out, remaining, files_written = [], response, []

        # unified diffs
        for m in re.compile(r'```diff\n(.*?)```', re.DOTALL).finditer(remaining):
            diff = m.group(1)
            fm = re.search(r'---\s+a/([^\n]+)', diff)
            if fm:
                fname = fm.group(1).strip()
                full  = fname if os.path.isabs(fname) else os.path.join(self.workspace, fname)
                tool_line("", "Applying patch", fname, running=True)
                self.undo.backup(full)
                result = self.fm.apply_diff(fname, diff)
                out.append(f"{GRN}  ✓{RST} {WB}{result}{RST}")
        remaining = re.sub(r'```diff\n.*?```', '', remaining, flags=re.DOTALL)

        # write_file
        for m in re.compile(r'<write_file\s+path=["\']([^"\']+)["\']>\n?(.*?)</write_file>', re.DOTALL).finditer(response):
            path, content = m.group(1).strip(), m.group(2)
            safe, resolved = validate_path(path if os.path.isabs(path) else os.path.join(self.workspace, path), self.workspace)
            if not safe:
                out.append(f"{RED}  ✗ blocked path: {path}{RST}")
                continue
            full = resolved
            self.undo.backup(full)
            os.makedirs(os.path.dirname(os.path.abspath(full)), exist_ok=True)
            with open(full, "w", encoding="utf-8") as f: f.write(content)
            lines_n = len(content.splitlines())
            files_written.append((path, lines_n))
            out.append(f"{GRN}  ✓{RST} {WB}{path}{RST} {DIM}({lines_n} lines){RST}")
        self.undo.save_manifest()
        remaining = re.sub(r'<write_file\s+path=["\'][^"\']+["\']>\n?.*?</write_file>', '', remaining, flags=re.DOTALL)

        # run_cmd — autorun check + path validation
        for m in re.compile(r'<run_cmd>\n?(.*?)</run_cmd>', re.DOTALL).finditer(response):
            cmd = m.group(1).strip()
            # Block commands targeting system paths
            safe = not any(p in cmd for p in ('/proc','/sys','/dev','/etc','/bin','/sbin','rm -rf /','rm -rf ~'))
            if safe and self.security_mode in ("medium", "high"):
                # Sandbox: block obvious attempts to escape the workspace
                if any(p in cmd for p in ('/sdcard','/storage','..','~')) and self.workspace not in cmd:
                    safe = False
            if not safe:
                out.append(f"{RED}  ✗ blocked command: {cmd[:60]}{RST}")
                continue
            tool_line("", "Bash", cmd, running=False)
            if _cfg["autorun"] and self.security_mode != "high":
                out.append(self._shell(cmd))
            else:
                if confirm_cmd(cmd):
                    out.append(self._shell(cmd))
                else:
                    out.append(f"{DIM}  skipped{RST}")
        remaining = re.sub(r'<run_cmd>\n?.*?</run_cmd>', '', remaining, flags=re.DOTALL)

        # delete_file — path validation
        for m in re.compile(r'<delete_file\s+path=["\']([^"\']+)["\']/?>', re.DOTALL).finditer(response):
            path = m.group(1).strip()
            full = path if os.path.isabs(path) else os.path.join(self.workspace, path)
            safe, resolved = validate_path(full, self.workspace)
            if not safe:
                out.append(f"{RED}  ✗ blocked delete: {path}{RST}")
                continue
            self.undo.backup(resolved)
            out.append(f"{GRN}  ✓{RST} {WB}{self.fm.delete(path)}{RST}")
        remaining = re.sub(r'<delete_file[^>]+/?>', '', remaining)

        # fallback code fences → auto-save
        ext_map = {"python":"py","py":"py","javascript":"js","js":"js","typescript":"ts",
                   "html":"html","css":"css","bash":"sh","sh":"sh","java":"java",
                   "go":"go","rust":"rs","cpp":"cpp","c":"c","json":"json","yaml":"yml","sql":"sql"}
        fc = 0
        for m in re.compile(r'```(\w+)?\n(.*?)```', re.DOTALL).finditer(remaining):
            lang, code = (m.group(1) or "txt").lower(), m.group(2)
            fc += 1
            fname = f"output.{ext_map.get(lang,lang)}" if fc==1 else f"output_{fc}.{ext_map.get(lang,lang)}"
            full  = os.path.join(self.workspace, fname)
            self.undo.backup(full)
            with open(full, "w", encoding="utf-8") as f: f.write(code)
            lines = len(code.splitlines())
            files_written.append((fname, lines))
            out.append(f"{GRN}  ✓{RST} {WB}{fname}{RST} {DIM}(auto-saved · {lines} lines){RST}")
        remaining = re.sub(r'```\w*\n.*?```', '', remaining, flags=re.DOTALL)

        if len(files_written) > 1:
            out.append(f"\n{W}  ▸ {len(files_written)} files · {sum(l for _,l in files_written)} lines total{RST}")

        # leftover prose — strip markdown formatting
        leftover = re.sub(r'<[^>]+>', '', remaining).strip()
        if leftover:
            out.append(f"{WB}{clean_markdown(leftover)}{RST}")

        return "\n".join(out) if out else "", files_written

    # ── Analyse: file-by-file, proper live status, no markdown leakage ────────
    def _analyse_cmd(self, target: str | None) -> str:
        out = []

        # Resolve path
        if target:
            target = target.strip().replace("~", os.path.expanduser("~")).rstrip(".,/")
            if not os.path.isabs(target):
                for base in (self.workspace, "/sdcard", os.path.expanduser("~"), "/storage/emulated/0"):
                    cand = os.path.join(base, target)
                    if os.path.exists(cand):
                        target = cand
                        break

        # Collect files
        if target and os.path.isdir(target):
            files = []
            for root, dirs, fs in os.walk(target):
                dirs[:] = [d for d in dirs if not d.startswith('.')
                           and d not in ('node_modules','__pycache__','.git','dist','build','vendor')]
                for f in sorted(fs):
                    if os.path.splitext(f)[1].lower() in CODE_EXTS:
                        files.append(os.path.join(root, f))
        elif target and os.path.isfile(target):
            files = [target]
        else:
            files = [
                os.path.join(root, f)
                for root, _, fs in os.walk(self.workspace)
                for f in fs if os.path.splitext(f)[1].lower() in CODE_EXTS
            ]

        if not files:
            if target:
                return f"{RED}  path not found: {target}{RST}\n{DIM}  tip: use !analyse /sdcard/yourfolder{RST}"
            return f"{DIM}  no code files found{RST}"

        total_files   = len(files)
        total_bugs    = 0
        patched_files = []

        # Claude Code style agent header
        agent_header(f"Analysing {total_files} file{'s' if total_files>1 else ''} in {os.path.basename(target or self.workspace)}")
        sys.stdout.write("\n".join(out) + ("\n" if out else ""))
        sys.stdout.flush()
        out = []

        # ── Process each file individually ────────────────────────────────────
        for idx, fpath in enumerate(files, 1):
            if not os.path.exists(fpath): continue
            fname = os.path.basename(fpath)
            rel   = os.path.relpath(fpath, target or self.workspace) if (target and os.path.isdir(target or "")) else fname

            # Claude Code style: └ Read(file)  Running...
            tool_line("", "Reading file", rel, running=True)

            try:
                with open(fpath, "r", encoding="utf-8", errors="ignore") as fh:
                    raw_content = fh.read()
            except Exception as e:
                status(f"  skip {fname} — {e}")
                continue

            # Sanitize file content — strip prompt injection attempts
            raw_content = sanitize_file_content(raw_content)
            line_count = len(raw_content.splitlines())

            # Lint
            lint_r   = lint_file(fpath, os.path.dirname(fpath))
            lint_str = f"\n\n[lint via {lint_r['tool']}]:\n{lint_r['output'][:400]}" if lint_r["tool"] else ""
            if lint_r["tool"]:
                tool_line("", "Lint", f"{rel} via {lint_r['tool']}", running=True)

            numbered   = "\n".join(f"{i+1:5}: {l}" for i, l in enumerate(raw_content.splitlines()))
            file_block = f"=== FILE: {rel} (full path: {fpath}) ===\n{numbered}{lint_str}"

            msgs = [
                {"role": "system", "content": ANALYSE_SYSTEM},
                {"role": "user",   "content": f"Analyse this file and fix all bugs:\n\n{file_block}"}
            ]

            tool_line("", "Analyse", f"{rel} · {line_count} lines", running=False)
            self.thinking.start()
            try:
                ai_raw = call_openrouter(msgs, get_active_model(), max_tokens=16000)
            finally:
                self.thinking.stop()

            self.tracker.track(msgs, ai_raw)

            # Parse bug report
            bugs     = re.findall(r'Bug \[([^\]]+)\]:\s*([^\n]+)', ai_raw)
            is_clean = bool(re.search(r'Clean:\s*' + re.escape(fname), ai_raw, re.IGNORECASE))

            if bugs:
                total_bugs += len(bugs)
                out.append(f"\n{WB}  {rel}{RST}  {YL}({len(bugs)} bug{'s' if len(bugs)>1 else ''} found){RST}")
                for loc, desc in bugs:
                    lnum   = re.search(r':(\d+)', loc)
                    ln_str = lnum.group(1) if lnum else "?"
                    tool_line("", "Patch", f"line {ln_str} — {clean_markdown(desc[:55])}")
                    out.append(f"  {YL}·{RST} {DIM}line {ln_str}:{RST} {WB}{clean_markdown(desc)}{RST}")

                _, written = self._process(ai_raw)
                if written:
                    patched_files.extend(written)
                    for ppath, plines in written:
                        out.append(f"  {GRN}✓ patched:{RST} {WB}{ppath}{RST} {DIM}({plines} lines){RST}")
                else:
                    out.append(f"  {YL}⚠ bugs reported but no patch written{RST}")

            elif is_clean:
                out.append(f"  {GRN}✓{RST} {DIM}{rel} — clean{RST}")
            else:
                plain = re.sub(r'<[^>]+>', '', ai_raw).strip()
                plain = clean_markdown(plain)
                if plain:
                    out.append(f"\n{WB}  {rel}:{RST}")
                    for line in plain.splitlines()[:15]:
                        out.append(f"  {DIM}{line}{RST}")
                _, written = self._process(ai_raw)

            # Print progress after each file so it's visible
            sys.stdout.write("\n".join(out) + "\n")
            sys.stdout.flush()
            out = []

        # ── Final summary ─────────────────────────────────────────────────────
        summary = []
        if total_bugs == 0:
            summary.append(f"\n{GRN}  ✓ all {total_files} files clean — no bugs found{RST}")
        else:
            summary.append(
                f"\n{WB}  ▸ {total_bugs} bug{'s' if total_bugs>1 else ''} found"
                f"  ·  {len(patched_files)} file{'s' if len(patched_files)>1 else ''} patched{RST}"
            )
            summary.append(f"{DIM}  tip: run !undo to revert all patches{RST}")

        return "\n".join(summary)

    # ── Tool loop ─────────────────────────────────────────────────────────────
    def _tool_loop(self, prev_result: str) -> str:
        out_lines = [prev_result] if prev_result else []
        written   = re.findall(r'✓\s+(\S+\.\w+)', prev_result or "")
        runnable  = [f for f in written if os.path.splitext(f)[1].lower() in RUNNERS]
        if not runnable: return prev_result or ""

        for attempt in range(1, MAX_FIX_LOOPS + 1):
            errors = {}
            for path in runnable:
                full = path if os.path.isabs(path) else os.path.join(self.workspace, path)
                if not os.path.exists(full): continue
                r = self._run_capture(full)
                if r["error"]: errors[path] = r["output"]

            if not errors:
                out_lines.append(f"{GRN}  ✓ ran OK{RST}")
                break

            first_err = next(iter(errors.values()))
            m = re.search(r'([\w]+error|[\w]+exception):?\s*([^\n]{0,60})', first_err, re.IGNORECASE)
            summary = m.group(0).strip() if m else f"{len(errors)} file(s) errored"

            out_lines.append(f"\n{YL}  ⚠ {summary}{RST}")
            for path, err in errors.items():
                for line in err.strip().splitlines()[:6]:
                    out_lines.append(f"  {DIM}{line}{RST}")

            if attempt == MAX_FIX_LOOPS:
                out_lines.append(f"{RED}  ✗ max fix attempts reached{RST}")
                break

            out_lines.append(f"{DIM}  ↻ fixing... ({attempt}/{MAX_FIX_LOOPS}){RST}")
            files_ctx = "\n".join(
                f"{p}:\n" + open(os.path.join(self.workspace, p), encoding="utf-8", errors="ignore").read()[:1200]
                for p in runnable if os.path.exists(os.path.join(self.workspace, p))
            )
            fix_msgs = [
                {"role": "system", "content": build_system_prompt(self.security_mode)},
                {"role": "user",   "content":
                    "Fix ALL errors. Use write_file tags only.\n\n"
                    "ERRORS:\n" + "\n\n".join(f"[{p}]\n{e}" for p,e in errors.items()) +
                    f"\n\nFILES:\n{files_ctx}"}
            ]
            self.thinking.start(f"Fixing: {summary[:40]}...")
            try:
                fix_raw = call_openrouter(fix_msgs, get_active_model(), max_tokens=16000)
            finally:
                self.thinking.stop()
            fix_out, _ = self._process(fix_raw)
            if fix_out: out_lines.append(fix_out)
            new_w = re.findall(r'✓\s+(\S+\.\w+)', fix_out or "")
            if new_w: runnable = [f for f in new_w if os.path.splitext(f)[1].lower() in RUNNERS]

        return "\n".join(out_lines)

    def _run_capture(self, full_path: str) -> dict:
        ext  = os.path.splitext(full_path)[1].lower()
        tmpl = RUNNERS.get(ext)
        if not tmpl: return {"output":"", "error":False}
        cmd  = tmpl.format(file=full_path, stem=os.path.splitext(os.path.basename(full_path))[0])
        try:
            r = subprocess.run(cmd, shell=True, capture_output=True, text=True,
                               timeout=15, cwd=self.workspace)
            out = (r.stdout + r.stderr).strip()
            err_kws = ("error","traceback","exception","syntaxerror","nameerror",
                       "typeerror","importerror","fatal","undefined is not")
            has_err = r.returncode != 0 or any(k in out.lower() for k in err_kws)
            return {"output": out, "error": has_err}
        except subprocess.TimeoutExpired:
            return {"output":"[timeout]", "error":True}
        except Exception as e:
            return {"output":str(e), "error":True}

    # ── Lint ──────────────────────────────────────────────────────────────────
    def _lint_cmd(self, target: str | None) -> str:
        exts = (".py",".js",".ts",".sh",".go")
        if target:
            target = target.replace("~", os.path.expanduser("~"))
            files  = [target] if os.path.isfile(target) else [
                os.path.join(r, f)
                for r, _, fs in os.walk(target)
                for f in fs if os.path.splitext(f)[1].lower() in exts
            ][:10]
        else:
            files = [
                os.path.join(r, f)
                for r, _, fs in os.walk(self.workspace)
                for f in fs if os.path.splitext(f)[1].lower() in exts
            ][:10]
        if not files: return f"{DIM}  no lintable files found{RST}"
        return "\n".join(
            fmt_lint(os.path.basename(p), lint_file(p, os.path.dirname(p)))
            for p in files
        )

    # ── Log ───────────────────────────────────────────────────────────────────
    def _log_cmd(self, target: str | None) -> str:
        if target:
            full = target if os.path.isabs(target) else os.path.join(self.workspace, target)
            if not os.path.exists(full): return f"{RED}  not found: {target}{RST}"
            return f"{DIM}{tail_log(full)}{RST}"
        logs = find_logs(self.workspace)
        if not logs: return f"{DIM}  no log files found{RST}"
        out = []
        for log in logs[:3]:
            out.append(f"{WB}  {os.path.relpath(log, self.workspace)}{RST}")
            out.append(f"{DIM}{tail_log(log, lines=20)}{RST}")
        return "\n".join(out)

    # ── Grep ──────────────────────────────────────────────────────────────────
    def _grep(self, pattern: str) -> str:
        tool_line("", "Searching repo", pattern, running=True)
        results = []
        for root, _, files in os.walk(self.workspace):
            for fname in files:
                fpath = os.path.join(root, fname)
                try:
                    with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                        for i, line in enumerate(f, 1):
                            if pattern.lower() in line.lower():
                                rel = os.path.relpath(fpath, self.workspace)
                                results.append(f"  {WB}{rel}{RST}:{DIM}{i}{RST}  {line.rstrip()}")
                except Exception: pass
        if not results: return f"{DIM}  no matches for '{pattern}'{RST}"
        return f"{WB}  {len(results)} matches for '{pattern}'{RST}\n" + "\n".join(results[:50])

    # ── Sync ──────────────────────────────────────────────────────────────────
    def _sync(self, src: str) -> str:
        src = src.replace("~", os.path.expanduser("~")).rstrip("/")
        dst = os.path.join(os.path.expanduser("~"), "moon")
        bak = dst + ".bak"
        if not os.path.isdir(src):
            return f"{RED}  not found: {src}{RST}"
        out = [f"{DIM}  sync {src} → {dst}{RST}"]
        if os.path.exists(bak): shutil.rmtree(bak, ignore_errors=True)
        if os.path.exists(dst):
            shutil.copytree(dst, bak)
            out.append(f"{DIM}  · backed up → moon.bak{RST}")
        r = subprocess.run(f'rsync -a --delete "{src}/" "{dst}/"',
                           shell=True, capture_output=True, text=True)
        if r.returncode == 0:
            out.append(f"{GRN}  ✓ synced{RST}")
        else:
            try:
                if os.path.exists(dst): shutil.rmtree(dst)
                shutil.copytree(src, dst)
                out.append(f"{GRN}  ✓ copied{RST} {DIM}(rsync unavailable){RST}")
            except Exception as e:
                if os.path.exists(bak): shutil.copytree(bak, dst)
                return f"{RED}  ✗ failed: {e}{RST}"
        out.append(f"{GRN}  ✓ restart to apply{RST}")
        return "\n".join(out)

    # ── Tests ─────────────────────────────────────────────────────────────────
    def _run_tests_cmd(self) -> str:
        tool_line("", "Running tests", "", running=True)
        result = run_tests(self.workspace)
        out = format_test_result(result)
        if result["failed"] > 0:
            out += f"\n{DIM}  tip: say 'fix the failing tests'{RST}"
        return out

    def _run_specific_test(self, target: str) -> str:
        status(f"running: {target}")
        result = run_specific_test(target, self.workspace)
        out    = format_test_result(result)
        if result["failed"] > 0:
            out += f"\n{DIM}  tip: say 'fix the failing tests'{RST}"
        return out

    # ── Status ────────────────────────────────────────────────────────────────
    def _status_cmd(self) -> str:
        hist    = len(self.history) // 2
        git_str = ""
        if is_git_repo(self.workspace):
            branch = subprocess.run("git branch --show-current", shell=True,
                                    capture_output=True, text=True, cwd=self.workspace).stdout.strip()
            git_str = f"\n{DIM}  git      :{RST} {WB}{branch}{RST}"
        autorun_str = (f"{DIM}n/a (high){RST}" if self.security_mode == "high"
                        else (f"{OR}on{RST}" if _cfg["autorun"] else f"{GRN}off{RST}"))
        search_str = f"{GRN}on{RST}" if _cfg["searchmode"] else f"{DIM}off{RST}"
        return (f"{DIM}  model    :{RST} {WB}{get_active_label()}{RST}"
                f"{git_str}\n"
                f"{DIM}  security :{RST} {WB}{self.security_mode}{RST}\n"
                f"{DIM}  autorun  :{RST} {autorun_str}\n"
                f"{DIM}  searchmode:{RST} {search_str}\n"
                f"{DIM}  ws       :{RST} {WB}{self.workspace}{RST}\n"
                f"{DIM}  files    :{RST} {WB}{self.scanner.count_files()}{RST}\n"
                f"{DIM}  history  :{RST} {WB}{hist} turns{RST}\n"
                f"{self.tracker.summary()}")

    # ── Shell ─────────────────────────────────────────────────────────────────
    def _shell(self, cmd: str) -> str:
        try:
            r = subprocess.run(cmd, shell=True, capture_output=True,
                               text=True, timeout=30, cwd=self.workspace)
            out = (r.stdout + r.stderr).strip()
            return f"{DIM}{out}{RST}" if out else f"{DIM}  [done]{RST}"
        except subprocess.TimeoutExpired:
            return f"{RED}  [timeout]{RST}"
        except Exception as e:
            return f"{RED}  [error] {e}{RST}"

    # ── Model ─────────────────────────────────────────────────────────────────
    def _switch_model(self) -> str:
        print(show_model_menu(), end="")
        choice = input().strip()
        if not choice: return f"{DIM}  [cancelled]{RST}"
        label = set_model(choice)
        if label:
            self.tracker.set_model(get_active_model())
            return f"{GRN}  ✓{RST} {WB}Model → {label}{RST}"
        return f"{RED}  [invalid]{RST}"

    # ── Security mode ─────────────────────────────────────────────────────────
    def _security_cmd(self, user_input: str) -> str:
        parts = user_input.strip().split(None, 1)
        arg   = parts[1].strip().lower() if len(parts) > 1 else ""

        if not arg:
            lines = [
                f"{DIM}  current  :{RST} {WB}{self.security_mode}{RST}",
                f"{DIM}  ws       :{RST} {WB}{self.workspace}{RST}",
                "",
                f"{WB}  low{RST}    {DIM}— full access: workspace, ~, /sdcard, /storage (system dirs blocked){RST}",
                f"{WB}  medium{RST} {DIM}— sandboxed to /sdcard/{SANDBOX_DIR_NAME}, commands follow !autorun{RST}",
                f"{WB}  high{RST}   {DIM}— sandboxed to /sdcard/{SANDBOX_DIR_NAME}, every command needs approval{RST}",
                "",
                f"{DIM}  usage: !security <low|medium|high>  (restart Moon to apply){RST}",
            ]
            return "\n".join(lines)

        if arg not in SECURITY_MODES:
            return f"{RED}  [invalid]{RST} {DIM}use: low, medium, or high{RST}"

        save_security_mode(arg)
        if arg in ("medium", "high"):
            sandbox = _find_or_create_sandbox()
            return (f"{GRN}  ✓{RST} {WB}security → {arg}{RST} {DIM}(saved){RST}\n"
                    f"{DIM}  sandbox  : {WB}{sandbox}{RST}\n"
                    f"{OR}  restart Moon to switch the workspace into the sandbox{RST}")
        return (f"{GRN}  ✓{RST} {WB}security → {arg}{RST} {DIM}(saved){RST}\n"
                f"{OR}  restart Moon to apply{RST}")

    def _confirm_delete(self, path: str) -> str:
        full = path if os.path.isabs(path) else os.path.join(self.workspace, path)
        safe, resolved = validate_path(full, self.workspace)
        if not safe:
            return f"{RED}  ✗ blocked delete: {path}{RST}"
        print(f"  {RED}Delete '{path}'?{RST} {DIM}[y/N]{RST} ", end="")
        if input().strip().lower() == "y":
            self.undo.backup(resolved)
            return f"{GRN}  ✓{RST} {WB}{self.fm.delete(path)}{RST}"
        return f"{DIM}  [cancelled]{RST}"

    # ── Help ──────────────────────────────────────────────────────────────────
    def _help(self) -> str:
        return f"""
{OR}  ┌──────────────────────────────────────────────────────┐{RST}
{OR}  │{RST}  {WB}!model  /model{RST}      {DIM}switch AI model            {OR}│{RST}
{OR}  │{RST}  {WB}!default <n>{RST}        {DIM}set + save default model   {OR}│{RST}
{OR}  │{RST}  {WB}!status /status{RST}     {DIM}model · git · cost · files {OR}│{RST}
{OR}  │{RST}  {WB}!cost{RST}               {DIM}token usage + cost         {OR}│{RST}
{OR}  │{RST}  {WB}!git{RST}                {DIM}git branch + diff          {OR}│{RST}
{OR}  │{RST}  {WB}!test [target]{RST}      {DIM}run all or specific tests  {OR}│{RST}
{OR}  │{RST}  {WB}!analyse [path]{RST}     {DIM}AI bug analysis            {OR}│{RST}
{OR}  │{RST}  {WB}!lint [path]{RST}        {DIM}lint files                 {OR}│{RST}
{OR}  │{RST}  {WB}!log [file]{RST}         {DIM}tail log files             {OR}│{RST}
{OR}  │{RST}  {WB}!search <term>{RST}      {DIM}grep across workspace      {OR}│{RST}
{OR}  │{RST}  {WB}!undo{RST}               {DIM}revert last AI patches     {OR}│{RST}
{OR}  │{RST}  {WB}!autorun true/false{RST} {DIM}toggle command autorun     {OR}│{RST}
{OR}  │{RST}  {WB}!security [mode]{RST}    {DIM}view/set low·medium·high   {OR}│{RST}
{OR}  │{RST}  {WB}!searchmode true/false{RST} {DIM}toggle URL/repo reading {OR}│{RST}
{OR}  │{RST}  {WB}!tree  /tree{RST}        {DIM}project file tree          {OR}│{RST}
{OR}  │{RST}  {WB}!read <file>{RST}        {DIM}print file contents        {OR}│{RST}
{OR}  │{RST}  {WB}!run <cmd>{RST}          {DIM}run shell command          {OR}│{RST}
{OR}  │{RST}  {WB}!delete <file>{RST}      {DIM}delete with confirmation   {OR}│{RST}
{OR}  │{RST}  {WB}!mkdir <dir>{RST}        {DIM}create directory           {OR}│{RST}
{OR}  │{RST}  {WB}!sync [path]{RST}        {DIM}replace ~/moon from sdcard {OR}│{RST}
{OR}  │{RST}  {WB}!clear  /clear{RST}      {DIM}clear history              {OR}│{RST}
{OR}  │{RST}  {WB}exit{RST}                {DIM}quit Moon                  {OR}│{RST}
{OR}{OR}  └──────────────────────────────────────────────────────┘{RST}"""