from typing import Optional
import os

MODELS = {
    # ── Free (OpenRouter) — coding / agentic focused ────────────────────────────
    "1":  {"label": "Poolside Laguna M.1    (free · agentic coding)", "id": "poolside/laguna-m.1:free"},
    "2":  {"label": "Poolside Laguna XS.2   (free · agentic coding)", "id": "poolside/laguna-xs.2:free"},
    "3":  {"label": "Kimi K2.6              (free · agentic coding)", "id": "moonshotai/kimi-k2.6:free"},
    "4":  {"label": "NVIDIA Nemotron Ultra  (free · agentic coding)", "id": "nvidia/nemotron-3-ultra-550b-a55b:free"},
    "5":  {"label": "NVIDIA Nemotron Super  (free · agentic coding)", "id": "nvidia/nemotron-3-super-120b-a12b:free"},
    "6":  {"label": "GLM 4.5 Air            (free · agentic)",        "id": "z-ai/glm-4.5-air:free"},
    "7":  {"label": "GPT-OSS 120B           (free)",                  "id": "openai/gpt-oss-120b:free"},
    "8":  {"label": "GPT-OSS 20B            (free)",                  "id": "openai/gpt-oss-20b:free"},
    "9":  {"label": "DeepSeek R1            (free)",                  "id": "deepseek/deepseek-r1:free"},
    "10": {"label": "NVIDIA Nemotron Nano   (free)",                  "id": "nvidia/nemotron-3-nano-30b-a3b:free"},
    "11": {"label": "Owl Alpha              (free · agentic)",        "id": "openrouter/owl-alpha"},
    "12": {"label": "Gemma 4 31B            (free)",                  "id": "google/gemma-4-31b-it:free"},
    "13": {"label": "Gemma 4 26B A4B        (free)",                  "id": "google/gemma-4-26b-a4b-it:free"},
    "14": {"label": "Nemotron Nano 9B V2    (free)",                  "id": "nvidia/nemotron-nano-9b-v2:free"},
    "15": {"label": "Auto Free              (free)",                  "id": "openrouter/free"},
    # ── OpenRouter paid ───────────────────────────────────────────────────────
    "16": {"label": "Claude 3.5 Haiku       (paid · OpenRouter)", "id": "anthropic/claude-3-5-haiku"},
    "17": {"label": "Claude Sonnet 4        (paid · OpenRouter)", "id": "anthropic/claude-sonnet-4"},
    "18": {"label": "DeepSeek Coder V2      (paid · OpenRouter)", "id": "deepseek/deepseek-coder-v2"},
    "19": {"label": "Qwen3 Coder Next       (paid · OpenRouter)", "id": "qwen/qwen3-coder-next"},
    # ── Direct APIs ───────────────────────────────────────────────────────────
    "20": {"label": "GPT-4o                 (OpenAI key)",        "id": "gpt-4o"},
    "21": {"label": "GPT-4o Mini            (OpenAI key)",        "id": "gpt-4o-mini"},
    "22": {"label": "Claude 3.5 Haiku       (Anthropic key)",     "id": "claude-3-5-haiku-20241022"},
    "23": {"label": "Claude Sonnet 4.5      (Anthropic key)",     "id": "claude-sonnet-4-5"},
    "24": {"label": "Gemini 2.0 Flash       (Gemini key)",        "id": "gemini-2.0-flash"},
    "25": {"label": "Gemini 1.5 Pro         (Gemini key)",        "id": "gemini-1.5-pro"},
    # ── Custom ────────────────────────────────────────────────────────────────
    "26": {"label": "Custom API             (API_CUSTOM env)",    "id": "custom/my-model"},
}

_CFG = os.path.join(os.path.dirname(__file__), "..", "config", "default_model.txt")

DEFAULT_MODEL_KEY   = "1"
_active_model_id:    str = MODELS[DEFAULT_MODEL_KEY]["id"]
_active_model_label: str = MODELS[DEFAULT_MODEL_KEY]["label"]

def get_active_model() -> str:  return _active_model_id
def get_active_label() -> str:  return _active_model_label

def set_model(key: str) -> Optional[str]:
    global _active_model_id, _active_model_label
    entry = MODELS.get(key)
    if not entry: return None
    _active_model_id    = entry["id"]
    _active_model_label = entry["label"]
    return _active_model_label

def set_default_model(key: str) -> Optional[str]:
    entry = MODELS.get(key)
    if not entry: return None
    try:
        with open(_CFG, "w") as f: f.write(key)
    except Exception: pass
    return set_model(key)

def _load_default():
    try:
        if os.path.exists(_CFG):
            with open(_CFG) as f:
                set_model(f.read().strip())
    except Exception: pass

_load_default()

def show_model_menu() -> str:
    CY  = "\033[38;2;157;92;255m"  # purple
    DIM = "\033[90m"
    WB  = "\033[97m"
    RST = "\033[0m"

    sections = [
        ("Free  (OpenRouter)",  [str(i) for i in range(1, 16)]),
        ("Paid  (OpenRouter)",  ["16","17","18","19"]),
        ("OpenAI  (direct)",    ["20","21"]),
        ("Anthropic  (direct)", ["22","23"]),
        ("Gemini  (direct)",    ["24","25"]),
        ("Custom API",          ["26"]),
    ]

    lines = [f"\n{CY}  ┌─ Select Model ──────────────────────────────────────────┐{RST}"]
    for section_label, keys in sections:
        lines.append(f"{CY}  │{RST}  {DIM}{section_label}{RST}")
        for k in keys:
            v      = MODELS[k]
            marker = f"{WB}●{RST}" if v["id"] == _active_model_id else f"{DIM}·{RST}"
            lines.append(f"{CY}  │{RST}  {marker} {k:>2}. {WB}{v['label']}{RST}")
    lines.append(f"{CY}  └──────────────────────────────────────────────────────────┘{RST}")
    lines.append(f"\n{CY}  Enter number (or ENTER to cancel): {RST}")
    return "\n".join(lines)
