"""
API Client — routes to OpenRouter, OpenAI, Anthropic, Gemini, or Custom endpoint.
"""
import os, json, time, urllib.request, urllib.error

CODING_SYSTEM_PROMPT = ""  # kept for imports

# ── Endpoints ─────────────────────────────────────────────────────────────────
ENDPOINTS = {
    "openrouter": "https://openrouter.ai/api/v1/chat/completions",
    "openai":     "https://api.openai.com/v1/chat/completions",
    "anthropic":  "https://api.anthropic.com/v1/messages",
    "gemini":     "https://generativelanguage.googleapis.com/v1beta/chat/completions",
    "custom":     os.environ.get("API_CUSTOM", ""),
}

KEYS = {
    "openrouter": lambda: os.environ.get("OPENROUTER_API_KEY",""),
    "openai":     lambda: os.environ.get("OPENAI_API_KEY",""),
    "anthropic":  lambda: os.environ.get("ANTHROPIC_API_KEY",""),
    "gemini":     lambda: os.environ.get("GEMINI_API_KEY",""),
    "custom":     lambda: os.environ.get("API_CUSTOM_KEY",""),
}

def _load_env_file():
    env_path = os.path.join(os.path.dirname(__file__), "..", "config", "api_key.env")
    if not os.path.exists(env_path): return
    with open(env_path) as f:
        for line in f:
            line = line.strip()
            if "=" in line and not line.startswith("#"):
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))

_load_env_file()

# Models that support reasoning effort control via OpenRouter
REASONING_MODELS = {
    "z-ai/glm-4.5-air:free",
    "openai/gpt-oss-120b:free",
    "openai/gpt-oss-20b:free",
    "openrouter/owl-alpha",
    "deepseek/deepseek-r1:free",
    "poolside/laguna-m.1:free",
    "poolside/laguna-xs.2:free",
    "nvidia/nemotron-3-ultra-550b-a55b:free",
    "nvidia/nemotron-3-super-120b-a12b:free",
    "nvidia/nemotron-nano-9b-v2:free",
    "anthropic/claude-3-5-haiku",
    "anthropic/claude-sonnet-4",
    "google/gemma-4-31b-it:free",
    "google/gemma-4-26b-a4b-it:free",
}

def detect_provider(model: str) -> str:
    m = model.lower()
    if m.startswith("custom/"):  return "custom"
    # Direct API models (no slash prefix)
    if m.startswith("gpt-"):     return "openai"
    if m.startswith("claude-"):  return "anthropic"
    if m.startswith("gemini-"):  return "gemini"
    # Everything with a slash = OpenRouter
    return "openrouter"

def call_openrouter(messages: list, model: str,
                    max_tokens: int = 8192, temperature: float = 0.2,
                    retries: int = 3) -> str:
    provider = detect_provider(model)
    url = ENDPOINTS.get(provider, ENDPOINTS["openrouter"])
    key = KEYS.get(provider, KEYS["openrouter"])()

    if not url:
        raise EnvironmentError(f"API_CUSTOM endpoint not set. Add to config/api_key.env")
    if not key:
        raise EnvironmentError(
            f"API key missing for provider '{provider}'.\n"
            f"Set the corresponding env var in config/api_key.env"
        )

    # Strip provider prefix for actual model name
    actual_model = model.split("/", 1)[1] if "/" in model and provider == "custom" else model

    body = {
        "model":       actual_model,
        "messages":    messages,
        "max_tokens":  max_tokens,
        "temperature": temperature,
    }
    # Always max reasoning for models that support it
    if model in REASONING_MODELS and provider == "openrouter":
        body["reasoning"] = {"effort": "high"}

    payload = json.dumps(body).encode("utf-8")

    headers = {
        "Content-Type":  "application/json",
        "Authorization": f"Bearer {key}",
    }
    if provider == "openrouter":
        headers["HTTP-Referer"] = "https://github.com/opcode-ai"
        headers["X-Title"]      = "Moon Terminal IDE"
    if provider == "anthropic":
        headers["x-api-key"]         = key
        headers["anthropic-version"]  = "2023-06-01"
        del headers["Authorization"]

    for attempt in range(1, retries + 1):
        try:
            req = urllib.request.Request(url, data=payload, headers=headers, method="POST")
            with urllib.request.urlopen(req, timeout=60) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                # Anthropic returns differently
                if provider == "anthropic":
                    return data["content"][0]["text"].strip()
                msg     = data["choices"][0]["message"]
                content = msg.get("content") or msg.get("reasoning") or ""
                return content.strip()

        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace")
            if e.code == 429:
                wait = 2 ** attempt
                print(f"  [rate limit] waiting {wait}s...")
                time.sleep(wait)
                continue
            if e.code in (401, 403):
                raise PermissionError(f"Auth failed for '{provider}'.\n{body}")
            raise RuntimeError(f"HTTP {e.code}: {body}")

        except urllib.error.URLError as e:
            if attempt < retries:
                time.sleep(1.5)
                continue
            raise ConnectionError(f"Network error: {e.reason}")

    raise RuntimeError("Max retries exceeded.")
