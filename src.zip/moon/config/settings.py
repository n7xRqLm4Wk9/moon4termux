"""
Settings — global configuration for Moon.
"""

import os

MOON_ROOT = os.path.dirname(os.path.dirname(__file__))

# Workspace path (override via env var) — used when security mode is LOW
WORKSPACE_DIR = os.environ.get(
    "MOON_WORKSPACE",
    os.path.join(MOON_ROOT, "workspace"),
)

# ── Security modes ──────────────────────────────────────────────────────────
# low    : full filesystem access (workspace, ~, /sdcard, /storage) — system
#          dirs still blocked. AI commands run per the !autorun setting.
# medium : sandboxed to /sdcard/moon-prj (created if missing). AI commands
#          run per the !autorun setting.
# high   : sandboxed to /sdcard/moon-prj (created if missing). EVERY AI
#          command (<run_cmd>) requires manual y/n confirmation, regardless
#          of !autorun.
SECURITY_MODES = ("low", "medium", "high")
DEFAULT_SECURITY_MODE = "medium"

SANDBOX_DIR_NAME = "moon-prj"
SANDBOX_CANDIDATES = ("/sdcard", "/storage/emulated/0")

_SECURITY_CFG = os.path.join(MOON_ROOT, "config", "security_mode.txt")


def _find_or_create_sandbox() -> str:
    """Locate an existing moon-prj dir on sdcard/storage, or create one."""
    for base in SANDBOX_CANDIDATES:
        cand = os.path.join(base, SANDBOX_DIR_NAME)
        if os.path.isdir(cand):
            return cand
    for base in SANDBOX_CANDIDATES:
        if os.path.isdir(base):
            cand = os.path.join(base, SANDBOX_DIR_NAME)
            try:
                os.makedirs(cand, exist_ok=True)
                return cand
            except Exception:
                continue
    # Fallback (e.g. non-Android dev env): keep it inside the project
    cand = os.path.join(MOON_ROOT, SANDBOX_DIR_NAME)
    os.makedirs(cand, exist_ok=True)
    return cand


def load_security_mode() -> str:
    try:
        if os.path.exists(_SECURITY_CFG):
            with open(_SECURITY_CFG) as f:
                mode = f.read().strip().lower()
            if mode in SECURITY_MODES:
                return mode
    except Exception:
        pass
    return DEFAULT_SECURITY_MODE


def save_security_mode(mode: str) -> bool:
    if mode not in SECURITY_MODES:
        return False
    try:
        with open(_SECURITY_CFG, "w") as f:
            f.write(mode)
        return True
    except Exception:
        return False


# Default AI parameters
DEFAULT_MAX_TOKENS = 2048
DEFAULT_TEMPERATURE = 0.2

# UI
PROMPT_SYMBOL = "▶ "
APP_NAME = "Moon"
APP_VERSION = "1.0.0"
